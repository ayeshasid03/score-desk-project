document.addEventListener("DOMContentLoaded", function() {
    
    // Pass vs Fail Pie Chart
    if (document.getElementById('passFailChart')) {
        const ctxPF = document.getElementById('passFailChart').getContext('2d');
        new Chart(ctxPF, {
            type: 'pie',
            data: {
                labels: ['Pass', 'Fail'],
                datasets: [{
                    data: [passCount, failCount],
                    backgroundColor: ['#198754', '#dc3545'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    }

    // Subject Average Bar Chart
    if (document.getElementById('subjectAvgChart')) {
        const ctxSub = document.getElementById('subjectAvgChart').getContext('2d');
        new Chart(ctxSub, {
            type: 'bar',
            data: {
                labels: subjectLabels,
                datasets: [{
                    label: 'Average Marks',
                    data: subjectAvgs,
                    backgroundColor: '#0d6efd',
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }

    // Semester Trend Line Chart
    if (document.getElementById('semTrendChart')) {
        const ctxSem = document.getElementById('semTrendChart').getContext('2d');
        new Chart(ctxSem, {
            type: 'line',
            data: {
                labels: semLabels,
                datasets: [{
                    label: 'Average Percentage (%)',
                    data: semAvgs,
                    borderColor: '#ffc107',
                    backgroundColor: 'rgba(255, 193, 7, 0.2)',
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }
});
