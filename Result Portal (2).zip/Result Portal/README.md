# Score Desk

A web-based academic result management system built with Python, Flask, SQLite, and Bootstrap 5. This project automates result calculation and provides an easy-to-use interface for administrators to manage student records, enter marks, and generate PDF report cards.

## Features
- **Admin Dashboard**: Analytics on pass/fail rates and subject-wise average marks.
- **Student Management**: Add, edit, delete student profiles.
- **Subject Management**: Configure subjects with custom pass/max marks.
- **Marks Entry**: Easy form-based marks entry and automatic result calculation.
- **Bulk Upload**: Import marks via Excel/CSV using the provided template.
- **Student Portal**: Public-facing page for students to search and view their results by roll number.
- **PDF Generation**: Downloadable PDF report cards.

## Setup Instructions

1. **Prerequisites**: Python 3.10+ installed.

2. **Create a Virtual Environment**:
   ```bash
   python -m venv venv
   ```

3. **Activate the Virtual Environment**:
   - Windows:
     ```bash
     venv\Scripts\activate
     ```
   - Mac/Linux:
     ```bash
     source venv/bin/activate
     ```

4. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

5. **Run the Application**:
   ```bash
   python app.py
   ```
   *The SQLite database (`database.db`) will be created automatically on the first run, along with a default admin account and sample subjects for BCA Semester 1.*

## Default Credentials
- **Username:** `admin`
- **Password:** `admin123`

## Bulk Upload Template
A sample template `sample_marks.xlsx` is provided in the root directory. Ensure your upload files strictly follow the same column headers.
