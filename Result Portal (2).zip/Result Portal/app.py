from flask import Flask
from config import Config
from models import db, User, Course, Subject
from werkzeug.security import generate_password_hash
import os

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    
    # Initialize plugins
    db.init_app(app)
    
    # Register Blueprints
    from routes.auth import auth_bp
    from routes.admin import admin_bp
    from routes.student import student_bp
    
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp, url_prefix='/admin')
    app.register_blueprint(student_bp)
    
    @app.route('/')
    def index():
        from flask import redirect, url_for
        return redirect(url_for('student.view_result'))
    
    # Ensure upload folder exists
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    
    with app.app_context():
        db.create_all()
        
        # Seed default admin user if not exists
        if not User.query.filter_by(username='admin').first():
            hashed_password = generate_password_hash('admin123')
            admin_user = User(username='admin', password_hash=hashed_password)
            db.session.add(admin_user)
            db.session.commit()
            print("Default admin created: admin / admin123")
        
        # Seed default BCA course and sample subjects if none exist
        if not Course.query.first():
            bca = Course(
                course_code='BCA',
                course_name='Bachelor of Computer Applications',
                duration_years=3
            )
            mca = Course(
                course_code='MCA',
                course_name='Master of Computer Applications',
                duration_years=2
            )
            bsc = Course(
                course_code='BSc CS',
                course_name='Bachelor of Science in Computer Science',
                duration_years=3
            )
            db.session.add_all([bca, mca, bsc])
            db.session.commit()
            print("Seeded 3 default courses: BCA, MCA, BSc CS")
            
            # Seed 5 sample subjects for BCA Semester 1
            sample_subjects = [
                Subject(subject_name='Programming in C',     subject_code='BCA101',  max_marks=100, pass_marks=40, semester=1, course_id=bca.id),
                Subject(subject_name='Mathematics I',         subject_code='BCA102',  max_marks=100, pass_marks=40, semester=1, course_id=bca.id),
                Subject(subject_name='Computer Fundamentals', subject_code='BCA103',  max_marks=100, pass_marks=40, semester=1, course_id=bca.id),
                Subject(subject_name='Communication Skills',  subject_code='BCA104',  max_marks=100, pass_marks=40, semester=1, course_id=bca.id),
                Subject(subject_name='C Programming Lab',     subject_code='BCA105P', max_marks=100, pass_marks=40, semester=1, course_id=bca.id),
            ]
            db.session.bulk_save_objects(sample_subjects)
            db.session.commit()
            print("Seeded 5 sample subjects for BCA Semester 1.")
            
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, port=5000)
