import os
from flask import Blueprint, render_template, request, current_app, send_file, flash, redirect, url_for
from models import Student, Result, Mark
from utils.pdf_generator import generate_report_card

student_bp = Blueprint('student', __name__)

@student_bp.route('/result', methods=['GET', 'POST'])
def view_result():
    student     = None
    result_data = []
    semesters   = []
    selected_sem = None

    if request.method == 'POST':
        roll_number  = request.form.get('roll_number', '').strip()
        selected_sem = request.form.get('semester', type=int)   # None if "All"

        if not roll_number:
            flash('Please enter a roll number.', 'warning')
            return redirect(url_for('student.view_result'))

        student = Student.query.filter_by(roll_number=roll_number).first()
        if not student:
            flash('No student found with that roll number.', 'danger')
            return redirect(url_for('student.view_result'))

        # All results for this student, newest first
        all_results = Result.query.filter_by(student_id=student.id)\
                                  .order_by(Result.semester.desc()).all()

        if not all_results:
            flash('No results published yet for this student.', 'info')
            return render_template('student/result.html', student=student,
                                   result_data=[], semesters=[], selected_sem=None)

        # Semesters for which results exist (for the dropdown)
        semesters = sorted({r.semester for r in all_results})

        # Filter by selected semester if provided
        if selected_sem:
            all_results = [r for r in all_results if r.semester == selected_sem]

        # Build result_data list
        for res in all_results:
            marks = Mark.query.join(Mark.subject).filter(
                Mark.student_id == student.id,
                Mark.subject.has(semester=res.semester)
            ).all()
            result_data.append({'result': res, 'marks': marks})

        return render_template('student/result.html',
                               student=student,
                               result_data=result_data,
                               semesters=semesters,
                               selected_sem=selected_sem)

    return render_template('student/result.html', student=None,
                           result_data=[], semesters=[], selected_sem=None)


@student_bp.route('/result/pdf/<roll_number>')
def download_pdf(roll_number):
    student = Student.query.filter_by(roll_number=roll_number).first_or_404()

    pdf_filename = f"{roll_number}_report_card.pdf"
    pdf_path = os.path.join(current_app.config['UPLOAD_FOLDER'], pdf_filename)

    success = generate_report_card(student.id, pdf_path)
    if success and os.path.exists(pdf_path):
        return send_file(pdf_path, as_attachment=True, download_name=pdf_filename)
    else:
        flash('Could not generate PDF or no results found.', 'danger')
        return redirect(url_for('student.view_result'))
