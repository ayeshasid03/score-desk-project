import os
from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app, session
from werkzeug.utils import secure_filename
from models import db, Student, Subject, Mark, Result, Course
from routes.auth import login_required
from utils.result_calculator import calculate_student_result
from utils.excel_parser import parse_excel_marks

admin_bp = Blueprint('admin', __name__)

# ─── Dashboard ────────────────────────────────────────────────────────────────

@admin_bp.route('/dashboard')
@login_required
def dashboard():
    total_students = Student.query.count()
    total_results  = Result.query.count()
    pass_count     = Result.query.filter_by(status='Pass').count()
    fail_count     = Result.query.filter_by(status='Fail').count()
    
    subjects = Subject.query.all()
    subject_labels, subject_avgs = [], []
    for sub in subjects:
        marks = Mark.query.filter_by(subject_id=sub.id).all()
        if marks:
            avg = sum(m.marks_obtained for m in marks) / len(marks)
            subject_labels.append(sub.subject_code)
            subject_avgs.append(round(avg, 2))
            
    sems = db.session.query(Result.semester, db.func.avg(Result.percentage))\
                     .group_by(Result.semester).all()
    sem_labels = [f"Sem {s[0]}" for s in sems]
    sem_avgs   = [round(s[1], 2) for s in sems]
    
    top_performers = Result.query.order_by(Result.percentage.desc()).limit(5).all()
    
    return render_template('admin/dashboard.html',
                           total_students=total_students,
                           total_results=total_results,
                           pass_count=pass_count,
                           fail_count=fail_count,
                           subject_labels=subject_labels,
                           subject_avgs=subject_avgs,
                           sem_labels=sem_labels,
                           sem_avgs=sem_avgs,
                           top_performers=top_performers)

# ─── Course Management ────────────────────────────────────────────────────────

@admin_bp.route('/courses', methods=['GET'])
@login_required
def courses():
    all_courses = Course.query.order_by(Course.course_code).all()
    return render_template('admin/courses.html', courses=all_courses)

@admin_bp.route('/courses/add', methods=['POST'])
@login_required
def add_course():
    code = request.form.get('course_code', '').strip().upper()
    if Course.query.filter_by(course_code=code).first():
        flash('Course code already exists.', 'danger')
    else:
        course = Course(
            course_code=code,
            course_name=request.form.get('course_name', '').strip(),
            duration_years=request.form.get('duration_years', 3, type=int)
        )
        db.session.add(course)
        db.session.commit()
        flash(f'Course "{code}" added successfully.', 'success')
    return redirect(url_for('admin.courses'))

@admin_bp.route('/courses/edit/<int:id>', methods=['POST'])
@login_required
def edit_course(id):
    course = Course.query.get_or_404(id)
    code   = request.form.get('course_code', '').strip().upper()
    if code != course.course_code and Course.query.filter_by(course_code=code).first():
        flash('Course code already in use.', 'danger')
    else:
        course.course_code    = code
        course.course_name    = request.form.get('course_name', '').strip()
        course.duration_years = request.form.get('duration_years', 3, type=int)
        db.session.commit()
        flash('Course updated successfully.', 'success')
    return redirect(url_for('admin.courses'))

@admin_bp.route('/courses/delete/<int:id>', methods=['POST'])
@login_required
def delete_course(id):
    course = Course.query.get_or_404(id)
    if course.students or course.subjects:
        flash('Cannot delete course: it has students or subjects linked to it.', 'danger')
    else:
        db.session.delete(course)
        db.session.commit()
        flash('Course deleted successfully.', 'success')
    return redirect(url_for('admin.courses'))

# ─── Student Management ───────────────────────────────────────────────────────

@admin_bp.route('/students', methods=['GET'])
@login_required
def students():
    search = request.args.get('search', '')
    page   = request.args.get('page', 1, type=int)
    
    query = Student.query
    if search:
        query = query.filter(
            db.or_(Student.full_name.ilike(f'%{search}%'),
                   Student.roll_number.ilike(f'%{search}%'))
        )
    pagination = query.order_by(Student.roll_number).paginate(page=page, per_page=10, error_out=False)
    return render_template('admin/students.html', pagination=pagination, search=search)

@admin_bp.route('/students/add', methods=['GET', 'POST'])
@login_required
def add_student():
    all_courses = Course.query.order_by(Course.course_code).all()
    if request.method == 'POST':
        roll_number = request.form.get('roll_number')
        if Student.query.filter_by(roll_number=roll_number).first():
            flash('Roll number already exists.', 'danger')
        else:
            student = Student(
                roll_number=roll_number,
                full_name=request.form.get('full_name'),
                course_id=request.form.get('course_id', type=int),
                semester=request.form.get('semester', type=int),
                email=request.form.get('email'),
                phone=request.form.get('phone')
            )
            db.session.add(student)
            db.session.commit()
            flash('Student added successfully.', 'success')
            return redirect(url_for('admin.students'))
    return render_template('admin/students_form.html', student=None, courses=all_courses)

@admin_bp.route('/students/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_student(id):
    student     = Student.query.get_or_404(id)
    all_courses = Course.query.order_by(Course.course_code).all()
    if request.method == 'POST':
        roll_number = request.form.get('roll_number')
        if roll_number != student.roll_number and Student.query.filter_by(roll_number=roll_number).first():
            flash('Roll number already in use.', 'danger')
        else:
            student.roll_number = roll_number
            student.full_name   = request.form.get('full_name')
            student.course_id   = request.form.get('course_id', type=int)
            student.semester    = request.form.get('semester', type=int)
            student.email       = request.form.get('email')
            student.phone       = request.form.get('phone')
            db.session.commit()
            flash('Student updated successfully.', 'success')
            return redirect(url_for('admin.students'))
    return render_template('admin/students_form.html', student=student, courses=all_courses)

@admin_bp.route('/students/delete/<int:id>', methods=['POST'])
@login_required
def delete_student(id):
    student = Student.query.get_or_404(id)
    db.session.delete(student)
    db.session.commit()
    flash('Student deleted successfully.', 'success')
    return redirect(url_for('admin.students'))

# ─── Subject Management ───────────────────────────────────────────────────────

@admin_bp.route('/subjects', methods=['GET'])
@login_required
def subjects():
    subjects_list = Subject.query.order_by(Subject.semester, Subject.subject_code).all()
    all_courses   = Course.query.order_by(Course.course_code).all()
    return render_template('admin/subjects.html', subjects=subjects_list, courses=all_courses)

@admin_bp.route('/subjects/add', methods=['POST'])
@login_required
def add_subject():
    code = request.form.get('subject_code')
    if Subject.query.filter_by(subject_code=code).first():
        flash('Subject Code already exists.', 'danger')
    else:
        subject = Subject(
            subject_name=request.form.get('subject_name'),
            subject_code=code,
            max_marks=request.form.get('max_marks', type=int),
            pass_marks=request.form.get('pass_marks', type=int),
            semester=request.form.get('semester', type=int),
            course_id=request.form.get('course_id', type=int)
        )
        db.session.add(subject)
        db.session.commit()
        flash('Subject added successfully.', 'success')
    return redirect(url_for('admin.subjects'))

@admin_bp.route('/subjects/edit/<int:id>', methods=['POST'])
@login_required
def edit_subject(id):
    subject = Subject.query.get_or_404(id)
    code    = request.form.get('subject_code')
    if code != subject.subject_code and Subject.query.filter_by(subject_code=code).first():
        flash('Subject Code already in use.', 'danger')
    else:
        subject.subject_code = code
        subject.subject_name = request.form.get('subject_name')
        subject.max_marks    = request.form.get('max_marks', type=int)
        subject.pass_marks   = request.form.get('pass_marks', type=int)
        subject.semester     = request.form.get('semester', type=int)
        subject.course_id    = request.form.get('course_id', type=int)
        db.session.commit()
        flash('Subject updated successfully.', 'success')
    return redirect(url_for('admin.subjects'))

@admin_bp.route('/subjects/delete/<int:id>', methods=['POST'])
@login_required
def delete_subject(id):
    subject = Subject.query.get_or_404(id)
    db.session.delete(subject)
    db.session.commit()
    flash('Subject deleted successfully.', 'success')
    return redirect(url_for('admin.subjects'))

# ─── Marks Entry ──────────────────────────────────────────────────────────────

@admin_bp.route('/marks/<int:student_id>', methods=['GET', 'POST'])
@login_required
def marks_entry(student_id):
    student  = Student.query.get_or_404(student_id)
    subjects = Subject.query.filter_by(semester=student.semester, course_id=student.course_id).all()
    existing_marks = {m.subject_id: m for m in Mark.query.filter_by(student_id=student.id).all()}
    
    if request.method == 'POST':
        exam_year = request.form.get('exam_year')
        errors    = False
        for sub in subjects:
            marks_str = request.form.get(f'marks_{sub.id}')
            if marks_str:
                marks_val = int(marks_str)
                if marks_val < 0 or marks_val > sub.max_marks:
                    flash(f'Invalid marks for {sub.subject_code}. Must be 0–{sub.max_marks}.', 'danger')
                    errors = True
                    continue
                mark_record = existing_marks.get(sub.id)
                if mark_record:
                    mark_record.marks_obtained = marks_val
                    mark_record.exam_year      = exam_year
                else:
                    db.session.add(Mark(student_id=student.id, subject_id=sub.id,
                                        marks_obtained=marks_val, exam_year=exam_year))
        if not errors:
            db.session.commit()
            calculate_student_result(student.id, student.semester)
            flash('Marks saved and result calculated successfully.', 'success')
            return redirect(url_for('admin.students'))
    return render_template('admin/marks.html', student=student, subjects=subjects, existing_marks=existing_marks)

# ─── Bulk Upload ──────────────────────────────────────────────────────────────

@admin_bp.route('/upload', methods=['GET', 'POST'])
@login_required
def bulk_upload():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part', 'danger')
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            flash('No selected file', 'danger')
            return redirect(request.url)
        if file and (file.filename.endswith('.xlsx') or file.filename.endswith('.csv')):
            filename = secure_filename(file.filename)
            filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            result = parse_excel_marks(filepath)
            if 'error' in result:
                for err in result.get('details', [result['error']]):
                    flash(err, 'danger')
                return redirect(request.url)
            session['upload_data'] = result['data']
            return redirect(url_for('admin.upload_preview'))
        else:
            flash('Invalid file format. Please upload .xlsx or .csv', 'danger')
    return render_template('admin/upload.html')

@admin_bp.route('/upload/preview', methods=['GET', 'POST'])
@login_required
def upload_preview():
    data = session.get('upload_data')
    if not data:
        flash('No data to preview.', 'warning')
        return redirect(url_for('admin.bulk_upload'))
    if request.method == 'POST':
        student_semesters = set()
        for row in data:
            mark = Mark.query.filter_by(student_id=row['student_id'], subject_id=row['subject_id']).first()
            if mark:
                mark.marks_obtained = row['marks_obtained']
                mark.exam_year      = row['exam_year']
            else:
                db.session.add(Mark(student_id=row['student_id'], subject_id=row['subject_id'],
                                    marks_obtained=row['marks_obtained'], exam_year=row['exam_year']))
            student_semesters.add((row['student_id'], row['semester']))
        db.session.commit()
        for s_id, sem in student_semesters:
            calculate_student_result(s_id, sem)
        session.pop('upload_data', None)
        flash('Bulk upload successful and results updated.', 'success')
        return redirect(url_for('admin.results'))
    return render_template('admin/upload_preview.html', data=data)

# ─── Results ──────────────────────────────────────────────────────────────────

@admin_bp.route('/results')
@login_required
def results():
    all_results = Result.query.join(Student).order_by(Student.roll_number, Result.semester).all()
    return render_template('admin/results.html', results=all_results)
