"""
seed_data.py — Run once to populate subjects for all courses and create sample students.
Usage: python seed_data.py
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from models import db, Course, Subject, Student

app = create_app()

# ─── Subject definitions per course ───────────────────────────────────────────

BCA_SUBJECTS = {
    1: [
        ("BCA101", "Programming in C"),
        ("BCA102", "Mathematics I"),
        ("BCA103", "Computer Fundamentals"),
        ("BCA104", "Communication Skills"),
        ("BCA105P", "C Programming Lab"),
    ],
    2: [
        ("BCA201", "Data Structures"),
        ("BCA202", "Mathematics II"),
        ("BCA203", "Operating Systems"),
        ("BCA204", "Database Management Systems"),
        ("BCA205P", "Data Structures Lab"),
    ],
    3: [
        ("BCA301", "Object Oriented Programming (Java)"),
        ("BCA302", "Computer Networks"),
        ("BCA303", "Software Engineering"),
        ("BCA304", "Web Technologies"),
        ("BCA305P", "Java Programming Lab"),
    ],
    4: [
        ("BCA401", "Python Programming"),
        ("BCA402", "Computer Graphics"),
        ("BCA403", "Theory of Computation"),
        ("BCA404", "Advanced DBMS"),
        ("BCA405P", "Web Development Lab"),
    ],
    5: [
        ("BCA501", "Artificial Intelligence"),
        ("BCA502", "Mobile Application Development"),
        ("BCA503", "Cyber Security"),
        ("BCA504", "Cloud Computing"),
        ("BCA505P", "AI & ML Lab"),
    ],
    6: [
        ("BCA601", "Machine Learning"),
        ("BCA602", "Big Data Analytics"),
        ("BCA603", "Project Management"),
        ("BCA604P", "Major Project"),
        ("BCA605", "Professional Ethics"),
    ],
}

MCA_SUBJECTS = {
    1: [
        ("MCA101", "Advanced Programming with C++"),
        ("MCA102", "Discrete Mathematics"),
        ("MCA103", "Computer Organization"),
        ("MCA104", "Data Structures & Algorithms"),
        ("MCA105P", "C++ Lab"),
    ],
    2: [
        ("MCA201", "Advanced Java"),
        ("MCA202", "Advanced DBMS"),
        ("MCA203", "Software Engineering"),
        ("MCA204", "Computer Networks"),
        ("MCA205P", "Java Lab"),
    ],
    3: [
        ("MCA301", "Machine Learning"),
        ("MCA302", "Cloud Architecture"),
        ("MCA303", "Cyber Security"),
        ("MCA304", "Mobile Computing"),
        ("MCA305P", "ML Lab"),
    ],
    4: [
        ("MCA401", "Distributed Systems"),
        ("MCA402", "Research Methodology"),
        ("MCA403P", "Major Research Project"),
        ("MCA404", "Seminar"),
        ("MCA405", "Open Elective"),
    ],
}

BSC_SUBJECTS = {
    1: [
        ("BSCCS101", "Programming Fundamentals (C)"),
        ("BSCCS102", "Mathematics I"),
        ("BSCCS103", "Digital Electronics"),
        ("BSCCS104", "English Communication"),
        ("BSCCS105P", "Programming Lab"),
    ],
    2: [
        ("BSCCS201", "Data Structures"),
        ("BSCCS202", "Mathematics II"),
        ("BSCCS203", "Operating Systems"),
        ("BSCCS204", "Database Systems"),
        ("BSCCS205P", "DS Lab"),
    ],
    3: [
        ("BSCCS301", "Java Programming"),
        ("BSCCS302", "Computer Networks"),
        ("BSCCS303", "Theory of Computation"),
        ("BSCCS304", "Web Design"),
        ("BSCCS305P", "Java Lab"),
    ],
    4: [
        ("BSCCS401", "Python & Data Science"),
        ("BSCCS402", "Software Engineering"),
        ("BSCCS403", "Artificial Intelligence"),
        ("BSCCS404", "Computer Graphics"),
        ("BSCCS405P", "Python Lab"),
    ],
    5: [
        ("BSCCS501", "Machine Learning"),
        ("BSCCS502", "Cloud Computing"),
        ("BSCCS503", "Internet of Things"),
        ("BSCCS504", "Cyber Security"),
        ("BSCCS505P", "ML Lab"),
    ],
    6: [
        ("BSCCS601", "Big Data Technologies"),
        ("BSCCS602", "Blockchain Technology"),
        ("BSCCS603P", "Final Year Project"),
        ("BSCCS604", "Entrepreneurship"),
        ("BSCCS605", "Professional Ethics"),
    ],
}

COURSE_MAP = {
    "BCA":    BCA_SUBJECTS,
    "MCA":    MCA_SUBJECTS,
    "BSc CS": BSC_SUBJECTS,
}

# ─── Students to create ────────────────────────────────────────────────────────

STUDENTS = [
    # BCA students — different semesters
    {"roll": "BCA2401", "name": "Aarav Sharma",   "course": "BCA", "sem": 1, "email": "aarav@example.com"},
    {"roll": "BCA2402", "name": "Priya Mehta",     "course": "BCA", "sem": 1, "email": "priya@example.com"},
    {"roll": "BCA2301", "name": "Rohan Gupta",     "course": "BCA", "sem": 3, "email": "rohan@example.com"},
    {"roll": "BCA2302", "name": "Sneha Joshi",     "course": "BCA", "sem": 3, "email": "sneha@example.com"},
    {"roll": "BCA2201", "name": "Karan Verma",     "course": "BCA", "sem": 5, "email": "karan@example.com"},
    {"roll": "BCA2202", "name": "Neha Singh",      "course": "BCA", "sem": 5, "email": "neha@example.com"},
    # MCA students
    {"roll": "MCA2401", "name": "Arjun Nair",      "course": "MCA", "sem": 1, "email": "arjun@example.com"},
    {"roll": "MCA2402", "name": "Divya Pillai",    "course": "MCA", "sem": 1, "email": "divya@example.com"},
    {"roll": "MCA2301", "name": "Rahul Iyer",      "course": "MCA", "sem": 3, "email": "rahul@example.com"},
    {"roll": "MCA2302", "name": "Anjali Rao",      "course": "MCA", "sem": 3, "email": "anjali@example.com"},
    # BSc CS students
    {"roll": "BSC2401", "name": "Vikram Patel",    "course": "BSc CS", "sem": 1, "email": "vikram@example.com"},
    {"roll": "BSC2402", "name": "Pooja Desai",     "course": "BSc CS", "sem": 1, "email": "pooja@example.com"},
    {"roll": "BSC2301", "name": "Amit Kumar",      "course": "BSc CS", "sem": 3, "email": "amit@example.com"},
    {"roll": "BSC2302", "name": "Riya Chatterjee", "course": "BSc CS", "sem": 3, "email": "riya@example.com"},
    {"roll": "BSC2201", "name": "Suresh Nair",     "course": "BSc CS", "sem": 5, "email": "suresh@example.com"},
    {"roll": "BSC2202", "name": "Deepa Menon",     "course": "BSc CS", "sem": 5, "email": "deepa@example.com"},
]

# ─── Run seeding ───────────────────────────────────────────────────────────────

def seed():
    with app.app_context():
        courses = {c.course_code: c for c in Course.query.all()}
        if not courses:
            print("ERROR: No courses found. Please run app.py first to seed default courses.")
            return

        # ── Subjects ──────────────────────────────────────────────────────────
        created_subjects = 0
        for course_code, sem_dict in COURSE_MAP.items():
            course = courses.get(course_code)
            if not course:
                print(f"  Course '{course_code}' not found, skipping.")
                continue
            for sem, subject_list in sem_dict.items():
                for code, name in subject_list:
                    if not Subject.query.filter_by(subject_code=code).first():
                        db.session.add(Subject(
                            subject_code=code,
                            subject_name=name,
                            max_marks=100,
                            pass_marks=40,
                            semester=sem,
                            course_id=course.id
                        ))
                        created_subjects += 1
        db.session.commit()
        print(f"[OK] Created {created_subjects} subjects across BCA, MCA, BSc CS")
        db.session.commit()

        # ── Students ──────────────────────────────────────────────────────────
        created_students = 0
        for s in STUDENTS:
            if Student.query.filter_by(roll_number=s["roll"]).first():
                continue
            course = courses.get(s["course"])
            if not course:
                continue
            db.session.add(Student(
                roll_number=s["roll"],
                full_name=s["name"],
                course_id=course.id,
                semester=s["sem"],
                email=s["email"],
                phone=None
            ))
            created_students += 1
        db.session.commit()
        print(f"[OK] Created {created_students} students across all courses")
        print("\nDone! Now run: python create_marks_excel.py  to generate the marks upload file.")

if __name__ == "__main__":
    seed()
