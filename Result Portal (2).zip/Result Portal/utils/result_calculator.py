from models import db, Result, Mark

def get_grade_and_points(percentage):
    if percentage >= 90:
        return 'O', 10
    elif percentage >= 75:
        return 'A+', 9
    elif percentage >= 60:
        return 'A', 8
    elif percentage >= 50:
        return 'B+', 7
    elif percentage >= 40:
        return 'B', 6
    else:
        return 'F', 0

def calculate_student_result(student_id, semester):
    marks_records = Mark.query.join(Mark.subject).filter(
        Mark.student_id == student_id,
        Mark.subject.has(semester=semester)
    ).all()
    
    if not marks_records:
        return None
    
    total_marks = 0
    total_max_marks = 0
    total_grade_points = 0
    status = 'Pass'
    
    for record in marks_records:
        obtained = record.marks_obtained
        subj_max = record.subject.max_marks
        subj_pass = record.subject.pass_marks
        
        total_marks += obtained
        total_max_marks += subj_max
        
        if obtained < subj_pass:
            status = 'Fail'
            
        # Calculate individual subject grade points
        subj_perc = (obtained / subj_max) * 100 if subj_max > 0 else 0
        _, pts = get_grade_and_points(subj_perc)
        total_grade_points += pts
        
    overall_percentage = (total_marks / total_max_marks) * 100 if total_max_marks > 0 else 0
    overall_grade, _ = get_grade_and_points(overall_percentage)
    
    # If any subject failed, overall grade is F
    if status == 'Fail':
        overall_grade = 'F'
        
    cgpa = total_grade_points / len(marks_records) if len(marks_records) > 0 else 0.0
    
    # Check if result already exists
    result = Result.query.filter_by(student_id=student_id, semester=semester).first()
    if not result:
        result = Result(student_id=student_id, semester=semester)
        db.session.add(result)
        
    result.total_marks = total_marks
    result.max_marks = total_max_marks
    result.percentage = round(overall_percentage, 2)
    result.grade = overall_grade
    result.cgpa = round(cgpa, 2)
    result.status = status
    
    db.session.commit()
    return result
