import os
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from models import Student, Result, Mark

def generate_report_card(student_id, output_path):
    student = Student.query.get(student_id)
    if not student:
        return False
        
    results = Result.query.filter_by(student_id=student.id).all()
    if not results:
        return False

    # Create the PDF document
    doc = SimpleDocTemplate(output_path, pagesize=letter)
    elements = []
    
    styles = getSampleStyleSheet()
    title_style = styles['Heading1']
    title_style.alignment = 1 # Center
    
    subtitle_style = styles['Heading2']
    subtitle_style.alignment = 1 # Center
    
    normal_style = styles['Normal']
    
    # Header
    elements.append(Paragraph("<b>SCORE DESK</b>", title_style))
    elements.append(Paragraph("<b>Academic Report Card</b>", subtitle_style))
    elements.append(Spacer(1, 20))
    
    # Student Details
    student_info = [
        [Paragraph("<b>Roll Number:</b>", normal_style), student.roll_number, Paragraph("<b>Course:</b>", normal_style), student.course],
        [Paragraph("<b>Name:</b>", normal_style), student.full_name, Paragraph("<b>Current Semester:</b>", normal_style), str(student.semester)]
    ]
    t_info = Table(student_info, colWidths=[100, 150, 100, 150])
    t_info.setStyle(TableStyle([
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 10)
    ]))
    elements.append(t_info)
    elements.append(Spacer(1, 20))
    
    # Iterate through all available results (semesters)
    for result in results:
        elements.append(Paragraph(f"<b>Semester: {result.semester}</b>", styles['Heading3']))
        elements.append(Spacer(1, 10))
        
        marks_records = Mark.query.join(Mark.subject).filter(
            Mark.student_id == student.id,
            Mark.subject.has(semester=result.semester)
        ).all()
        
        data = [['Subject Code', 'Subject Name', 'Max Marks', 'Pass Marks', 'Marks Obtained']]
        
        for m in marks_records:
            data.append([
                m.subject.subject_code,
                m.subject.subject_name,
                str(m.subject.max_marks),
                str(m.subject.pass_marks),
                str(m.marks_obtained)
            ])
            
        t_marks = Table(data, colWidths=[80, 200, 70, 70, 100])
        t_marks.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.grey),
            ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
            ('ALIGN', (0,0), (-1,-1), 'CENTER'),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0,0), (-1,0), 12),
            ('BACKGROUND', (0,1), (-1,-1), colors.beige),
            ('GRID', (0,0), (-1,-1), 1, colors.black),
        ]))
        elements.append(t_marks)
        elements.append(Spacer(1, 15))
        
        # Result summary table
        summary_data = [
            ['Total Marks', 'Percentage', 'CGPA', 'Grade', 'Status'],
            [f"{result.total_marks}/{result.max_marks}", f"{result.percentage}%", str(result.cgpa), result.grade, result.status]
        ]
        t_summary = Table(summary_data, colWidths=[104, 104, 104, 104, 104])
        t_summary.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.lightblue),
            ('ALIGN', (0,0), (-1,-1), 'CENTER'),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('GRID', (0,0), (-1,-1), 1, colors.black),
            ('TEXTCOLOR', (-1,-1), (-1,-1), colors.green if result.status == 'Pass' else colors.red)
        ]))
        elements.append(t_summary)
        elements.append(Spacer(1, 30))
        
    doc.build(elements)
    return True
