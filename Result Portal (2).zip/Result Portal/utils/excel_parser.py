import pandas as pd
from models import Student, Subject

def parse_excel_marks(file_path):
    try:
        df = pd.read_excel(file_path)
    except Exception as e:
        return {"error": f"Failed to read file: {str(e)}"}
        
    # Normalize column names: lowercase + strip so both 'Roll Number' and 'roll_number' work
    col_map = {
        'roll_number':    'Roll Number',
        'subject_code':   'Subject Code',
        'marks_obtained': 'Marks Obtained',
        'exam_year':      'Exam Year',
    }
    df.columns = [col_map.get(c.strip().lower().replace(' ', '_'), c.strip()) for c in df.columns]

    required_cols = ['Roll Number', 'Subject Code', 'Marks Obtained', 'Exam Year']
    for col in required_cols:
        if col not in df.columns:
            return {"error": f"Missing required column: {col}"}
            
    parsed_data = []
    errors = []
    
    # Pre-fetch valid students and subjects to minimize DB queries
    valid_students = {s.roll_number: s for s in Student.query.all()}
    valid_subjects = {s.subject_code: s for s in Subject.query.all()}
    
    for index, row in df.iterrows():
        roll_no = str(row['Roll Number']).strip()
        sub_code = str(row['Subject Code']).strip()
        marks = row['Marks Obtained']
        exam_year = str(row['Exam Year']).strip()
        
        row_error = []
        
        if roll_no not in valid_students:
            row_error.append(f"Invalid Roll Number: {roll_no}")
        if sub_code not in valid_subjects:
            row_error.append(f"Invalid Subject Code: {sub_code}")
            
        if pd.isna(marks) or not isinstance(marks, (int, float)) or marks < 0:
            row_error.append(f"Invalid Marks: {marks}")
        elif sub_code in valid_subjects and marks > valid_subjects[sub_code].max_marks:
            row_error.append(f"Marks exceed max marks ({valid_subjects[sub_code].max_marks})")
            
        if row_error:
            errors.append(f"Row {index + 2}: " + " | ".join(row_error))
        else:
            student = valid_students[roll_no]
            subject = valid_subjects[sub_code]
            parsed_data.append({
                'student_id': student.id,
                'subject_id': subject.id,
                'marks_obtained': int(marks),
                'exam_year': exam_year,
                'roll_number': roll_no,
                'student_name': student.full_name,
                'subject_name': subject.subject_name,
                'semester': subject.semester
            })
            
    if errors:
        return {"error": "Validation failed", "details": errors}
        
    return {"success": True, "data": parsed_data}
