"""
create_marks_excel.py — Generates sample_marks.xlsx for bulk upload.
Run AFTER seed_data.py so students and subjects are in the DB.
Usage: python create_marks_excel.py
"""

import sys, os, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from models import Student, Subject

app = create_app()

def make_excel():
    with app.app_context():
        students = Student.query.all()
        if not students:
            print("ERROR: No students found. Run seed_data.py first.")
            return

        rows = []
        for student in students:
            subjects = Subject.query.filter_by(
                course_id=student.course_id,
                semester=student.semester
            ).all()
            if not subjects:
                print(f"  No subjects for {student.roll_number} (sem {student.semester}) — skipping.")
                continue

            for sub in subjects:
                # Random realistic marks: 40–100, weighted toward passing
                marks = random.choices(
                    [random.randint(40, 100), random.randint(20, 39)],
                    weights=[92, 8]
                )[0]
                rows.append({
                    "roll_number": student.roll_number,
                    "subject_code": sub.subject_code,
                    "marks_obtained": marks,
                    "exam_year": "2024"
                })

        if not rows:
            print("No data rows generated.")
            return

        try:
            import pandas as pd
            df = pd.DataFrame(rows, columns=["roll_number", "subject_code", "marks_obtained", "exam_year"])
            out = "bulk_marks_upload.xlsx"
            df.to_excel(out, index=False)
            print(f"[OK] Generated '{out}' with {len(rows)} rows for {len(students)} students.")
            print(f"  Upload this file at: http://127.0.0.1:5000/admin/upload")
        except ImportError:
            print("pandas not installed — generating CSV instead.")
            import csv
            out = "sample_marks.csv"
            with open(out, "w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=["roll_number", "subject_code", "marks_obtained", "exam_year"])
                writer.writeheader()
                writer.writerows(rows)
            print(f"✓ Generated '{out}' with {len(rows)} rows.")

if __name__ == "__main__":
    make_excel()
